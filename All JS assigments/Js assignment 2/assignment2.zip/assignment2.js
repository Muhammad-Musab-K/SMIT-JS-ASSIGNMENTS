//Qno 1 And Qno 2
var num1 = 9
var num2 = 13
var plus = 9 + 13
var minus = 13 - 9
var multiply = 13 * 9
var divide = 13 / 9


alert('sum of ' + num1 + ' and ' + num2 + ' is ' + plus)
alert('Result of substract of ' + num1 + ' and ' + num2 + ' is ' + minus)
alert('Result of multiplying of ' + num1 + ' and ' + num2 + ' is ' + multiply)
alert('Result of division of ' + num1 + ' and ' + num2 + ' is ' + divide)

//Qno3 and 4

var num3 
alert('Value after decrelation the variable is ' + num3 )
var num4 = 3
alert('initail value is ' + num4)
var incre = ++num4 
alert('Value after increment is ' + incre)
var addition = incre + 7
alert('Value after addition is ' + addition)
var decre = --addition
alert('Value after decrement is ' + decre) 
var reminder = decre / decre
alert('value of reminder is ' + reminder)


var ticket = 600
var quantity = 5
var totalCost = 5 * 600

alert('Total cost of ' + quantity + ' tickets is ' + totalCost)


//Qno5 and 6
var four = 4
var table = prompt("Enter the number")
var result = four * table

alert('4 x = ' + result)

var celsius = 20
var fehrenheit = 68

var formula = (fehrenheit - 32) * 5 / 9
alert('68F is equal to ' + formula + 'C')
var formula2 = (celsius * 9/5) + 32
alert('20C is equal to ' +  formula2 + 'F') 


//Qno 7 and 8

var itemOne = 560
var itemTwo = 200
var quantity = 2
var quantity1 = 2
var shippingCharges = 150
var totalPese = itemOne * quantity + itemTwo * quantity1 + shippingCharges

alert('The price of item one is ' + itemOne)
alert('The price of item two is ' + itemTwo)
alert('Quantity of item one is ' + quantity)
alert('Quantity of item two is ' + quantity1)
alert('shipping charges is ' + shippingCharges) 
alert('Total cost is ' + totalPese)


var obtainMarks = 900
var totalMarks = 1200
var percentage = 900/1200 * 100

alert('Obtain Marks ' + obtainMarks )
alert('Total Marks ' + totalMarks)  
alert('Percentage ' + percentage + '%')


//Qno 9 and 10 
var currencyDollar = prompt("Calculate PKR into $")
var DollarCurrency = 287 * currencyDollar
alert(DollarCurrency +  ' PKR')
var currencyDhiram = prompt("Calculate PKR into AED")
var Dhiram = 80 * currencyDhiram
alert(Dhiram + ' PKR')

var digit = 10
var dmas = 10 + 5 * 10 / 2
alert(dmas)


//Qno11 and 12

var YearOfBirth = prompt('Enter Year of Birth')
var currentAge = 2023 - YearOfBirth 
alert('Your Current Age is ' + currentAge)




var radius = prompt('Calcualte the circumference of the circle on the basis of Radius')
var circum = 2 * 3.142 * radius
alert('Circumference of the circle is ' + circum)

var radius = prompt('Calcualte the area of the circle on the basis of Radius')
var area = 3.142 * radius * radius
alert('Area of the circle is ' + area)


//Qno 13 and 14

var a = 10
alert('The value of a is ' + a)
var increm = ++a
alert('The value of  ++a is ' + increm + '. Now the value of a is 11' )
var pIncrem = a++
alert('The value of a++ is ' + pIncrem  + '. No the value of a is 12')
var decrem = --a
alert('The value of --a is ' + decrem + '. Now the value of a is 11')
var pDecrem = a--
alert('The value of a-- is ' + pDecrem + '. Now the value of a is 10')

var aye = 2
var bee = 1
var nateeja = --aye - --bee + ++bee + bee--

alert('a is ' + aye + ' and ' + 'b is ' + bee)
alert('The result of  this equation (--a - --b + ++b + b--) is ' + nateeja)

//Qno15

var snack = "Wavy"
var currentUmar = 20
var maxAge = 70
var snackperyear = 150
var totalSnack = 150 * 20 - 70

alert('You will need ' + totalSnack + ' ' + snack + ' to last you until the ripe old age is ' + maxAge)
